from typing import Dict, Tuple
import pandas as pd

class CurrencyConverter:
    def __init__(self, exchange_rates_df: pd.DataFrame):
        # Store rates indexed by (rate_date, from_curr, to_curr)
        self.rates: Dict[Tuple[str, str, str], float] = {}
        for _, row in exchange_rates_df.iterrows():
            d = str(row['rate_date']).strip()
            f = str(row['from_currency']).strip()
            t = str(row['to_currency']).strip()
            r = float(row['rate'])
            self.rates[(d, f, t)] = r
            if r > 0 and (d, t, f) not in self.rates:
                self.rates[(d, t, f)] = 1.0 / r

    def convert(self, amount: float, from_curr: str, to_curr: str, rate_date: str) -> float:
        if from_curr == to_curr:
            return amount
        key = (rate_date, from_curr, to_curr)
        if key in self.rates:
            return amount * self.rates[key]
        
        # Fallback: find closest available rate date for the currency pair
        matching_dates = [d for (d, f, t) in self.rates.keys() if f == from_curr and t == to_curr]
        if matching_dates:
            closest_date = min(matching_dates, key=lambda x: abs((pd.to_datetime(x) - pd.to_datetime(rate_date)).days))
            return amount * self.rates[(closest_date, from_curr, to_curr)]
        
        # Cross-rate through USD or EUR if needed
        for intermediate in ['USD', 'EUR']:
            k1 = (rate_date, from_curr, intermediate)
            k2 = (rate_date, intermediate, to_curr)
            if k1 in self.rates and k2 in self.rates:
                return amount * self.rates[k1] * self.rates[k2]
        
        # If no rate found, return amount as-is
        return amount
