import os
from typing import Dict, List, Optional, Tuple
import pandas as pd
import numpy as np

from models import (
    FinancialProfile,
    FinancialEvent,
    PaymentOption,
    Message,
    EvaluationRequest
)
from currency import CurrencyConverter
from image_processor import ImageProcessor

class DataLoader:
    def __init__(self, dataset_dir: str):
        self.dataset_dir = dataset_dir
        self.currency_converter: Optional[CurrencyConverter] = None
        self.image_processor: Optional[ImageProcessor] = None

    def load_exchange_rates(self) -> CurrencyConverter:
        path = os.path.join(self.dataset_dir, 'exchange_rates.csv')
        df = pd.read_csv(path)
        self.currency_converter = CurrencyConverter(df)
        return self.currency_converter

    def load_images(self) -> ImageProcessor:
        path = os.path.join(self.dataset_dir, 'images.csv')
        media_dir = os.path.join(self.dataset_dir, 'media', 'images')
        df = pd.read_csv(path) if os.path.exists(path) else None
        self.image_processor = ImageProcessor(df, media_dir)
        return self.image_processor

    def load_profiles(self) -> Dict[str, FinancialProfile]:
        path = os.path.join(self.dataset_dir, 'financial_profiles.csv')
        df = pd.read_csv(path)
        profiles = {}
        for _, r in df.iterrows():
            def parse_pipe(val):
                if pd.isna(val):
                    return []
                return [s.strip() for s in str(val).split('|') if s.strip()]

            u_id = str(r['user_id']).strip()
            max_inst = None if pd.isna(r.get('max_installment_months')) else float(r['max_installment_months'])
            
            p = FinancialProfile(
                user_id=u_id,
                home_currency=str(r['home_currency']).strip(),
                current_available_balance=float(r['current_available_balance']),
                minimum_balance_to_keep=float(r['minimum_balance_to_keep']),
                financial_priorities=parse_pipe(r.get('financial_priorities')),
                expense_categories_to_protect=parse_pipe(r.get('expense_categories_to_protect')),
                expense_categories_user_is_willing_to_reduce=parse_pipe(r.get('expense_categories_user_is_willing_to_reduce')),
                expense_categories_user_is_willing_to_stop=parse_pipe(r.get('expense_categories_user_is_willing_to_stop')),
                payment_methods_user_will_consider=parse_pipe(r.get('payment_methods_user_will_consider')),
                max_installment_months=max_inst
            )
            profiles[u_id] = p
        return profiles

    def load_events(self) -> Dict[str, List[FinancialEvent]]:
        path = os.path.join(self.dataset_dir, 'financial_events.csv')
        df = pd.read_csv(path)
        events_by_user: Dict[str, List[FinancialEvent]] = {}

        for _, r in df.iterrows():
            ev_id = str(r['event_id']).strip()
            u_id = str(r['user_id']).strip()
            
            # Amount resolution
            amt = r.get('amount')
            if pd.isna(amt):
                if self.image_processor:
                    resolved = self.image_processor.get_amount_for_event(ev_id)
                    amt = resolved if resolved is not None else 0.0
                else:
                    amt = 0.0
            else:
                amt = float(amt)

            linked = None if pd.isna(r.get('linked_event_id')) else str(r['linked_event_id']).strip()
            min_amt = None if pd.isna(r.get('minimum_allowed_amount')) else float(r['minimum_allowed_amount'])
            settle_date = str(r['settlement_date']).strip() if pd.notna(r.get('settlement_date')) else str(r['event_date']).strip()

            ev = FinancialEvent(
                event_id=ev_id,
                user_id=u_id,
                event_type=str(r['event_type']).strip(),
                description=str(r['description']).strip(),
                category=str(r['category']).strip(),
                direction=str(r['direction']).strip(),
                amount=amt,
                currency=str(r['currency']).strip(),
                event_date=str(r['event_date']).strip(),
                settlement_date=settle_date,
                status=str(r['status']).strip(),
                linked_event_id=linked,
                flexibility=str(r['flexibility']).strip(),
                minimum_allowed_amount=min_amt
            )
            events_by_user.setdefault(u_id, []).append(ev)
        return events_by_user

    def load_payment_options(self) -> Dict[str, List[PaymentOption]]:
        path = os.path.join(self.dataset_dir, 'request_payment_options.csv')
        df = pd.read_csv(path)
        opts_by_req: Dict[str, List[PaymentOption]] = {}

        for _, r in df.iterrows():
            req_id = str(r['request_id']).strip()
            freq = None if pd.isna(r.get('payment_frequency_days')) else float(r['payment_frequency_days'])
            
            opt = PaymentOption(
                payment_option_id=str(r['payment_option_id']).strip(),
                request_id=req_id,
                payment_method=str(r['payment_method']).strip(),
                payment_amount=float(r['payment_amount']),
                number_of_payments=int(r['number_of_payments']),
                first_payment_date=str(r['first_payment_date']).strip(),
                payment_frequency_days=freq,
                financing_fee=float(r['financing_fee']),
                total_payable_amount=float(r['total_payable_amount'])
            )
            opts_by_req.setdefault(req_id, []).append(opt)
        return opts_by_req

    def load_messages(self) -> List[Message]:
        path = os.path.join(self.dataset_dir, 'messages.csv')
        df = pd.read_csv(path)
        msgs = []
        for _, r in df.iterrows():
            req_id = None if pd.isna(r.get('request_id')) else str(r['request_id']).strip()
            ev_id = None if pd.isna(r.get('related_event_id')) else str(r['related_event_id']).strip()
            m = Message(
                message_id=str(r['message_id']).strip(),
                user_id=str(r['user_id']).strip(),
                request_id=req_id,
                related_event_id=ev_id,
                sent_at=str(r['sent_at']).strip(),
                source_type=str(r['source_type']).strip(),
                message_text=str(r['message_text']).strip()
            )
            msgs.append(m)
        return msgs

    def load_requests(self, filename: str = 'requests.csv') -> List[EvaluationRequest]:
        path = os.path.join(self.dataset_dir, filename)
        df = pd.read_csv(path)
        reqs = []
        for _, r in df.iterrows():
            req = EvaluationRequest(
                request_id=str(r['request_id']).strip(),
                user_id=str(r['user_id']).strip(),
                request_date=str(r['request_date']).strip(),
                request_type=str(r['request_type']).strip(),
                requested_amount=float(r['requested_amount']),
                desired_completion_date=str(r['desired_completion_date']).strip(),
                allows_partial_payment=bool(r['allows_partial_payment']),
                request_text=str(r['request_text']).strip()
            )
            reqs.append(req)
        return reqs
