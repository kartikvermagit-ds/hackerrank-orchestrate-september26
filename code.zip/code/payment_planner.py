from typing import List, Dict, Tuple, Optional
from datetime import datetime, timedelta
import pandas as pd
from models import EvaluationRequest, PaymentOption, CandidatePlan
from financial_state import FinancialState
from forecast import ForecastEngine

class PaymentPlanner:
    def __init__(self, forecast_engine: ForecastEngine):
        self.forecaster = forecast_engine

    def generate_candidate_plans(self, request: EvaluationRequest,
                                 state: FinancialState,
                                 options: List[PaymentOption],
                                 amount_safe_to_pay: float,
                                 earliest_date_for_full_payment: Optional[str],
                                 spending_changes: Optional[List[str]] = None) -> List[CandidatePlan]:
        """Generates all eligible candidate plans for a given spending_changes profile."""
        if spending_changes is None:
            spending_changes = []

        plans: List[CandidatePlan] = []
        req_amt = request.requested_amount
        req_date = request.request_date
        due_date = request.desired_completion_date

        # 1. Full Payment Candidate
        if 'full_payment' in state.allowed_payment_methods:
            full_sched = [(req_date, req_amt)]
            payments_dict = {req_date: req_amt}
            min_seen, is_safe, _ = self.forecaster.simulate_schedule(
                state, req_date, proposed_payments=payments_dict, spending_changes=spending_changes
            )
            # Full payment on request_date finishes by due_date if req_date <= due_date
            finishes_in_time = (req_date <= due_date)
            status = 'affordable_now' if (is_safe and not spending_changes) else ('affordable_with_plan' if is_safe else 'not_affordable')
            
            plans.append(CandidatePlan(
                method='full_payment',
                payment_schedule=full_sched,
                spending_changes=list(spending_changes),
                total_amount=req_amt,
                first_payment_date=req_date,
                number_of_payments=1,
                payment_option_id=None,
                is_safe=(is_safe and finishes_in_time),
                affordability_status=status,
                earliest_date_for_full_payment=req_date if (is_safe and not spending_changes) else earliest_date_for_full_payment
            ))

        # 2. Partial Payment Candidate
        if (request.allows_partial_payment and 
            'partial_payment' in state.allowed_payment_methods and 
            0 < amount_safe_to_pay < req_amt and 
            earliest_date_for_full_payment is not None and 
            earliest_date_for_full_payment <= due_date and
            not spending_changes):  # Partial payment is evaluated before spending changes per challenge contract
            
            remainder = round(req_amt - amount_safe_to_pay, 2)
            part_sched = [(req_date, amount_safe_to_pay), (earliest_date_for_full_payment, remainder)]
            payments_dict = {req_date: amount_safe_to_pay, earliest_date_for_full_payment: remainder}
            h_days = (pd.to_datetime(earliest_date_for_full_payment) - pd.to_datetime(req_date)).days
            
            min_seen, is_safe, _ = self.forecaster.simulate_schedule(
                state, req_date, proposed_payments=payments_dict, spending_changes=[], horizon_days=h_days
            )
            if is_safe:
                plans.append(CandidatePlan(
                    method='partial_payment',
                    payment_schedule=part_sched,
                    spending_changes=[],
                    total_amount=req_amt,
                    first_payment_date=req_date,
                    number_of_payments=2,
                    payment_option_id=None,
                    is_safe=True,
                    affordability_status='affordable_with_plan',
                    earliest_date_for_full_payment=earliest_date_for_full_payment
                ))

        # 3. Installment Options from request_payment_options.csv
        if 'installments' in state.allowed_payment_methods:
            for opt in options:
                if opt.payment_method != 'installments':
                    continue

                # Check max installment tenure
                if state.max_installment_months is not None:
                    # An option with N payments spaced by freq days
                    freq = opt.payment_frequency_days if opt.payment_frequency_days else 30.0
                    total_duration_days = (opt.number_of_payments - 1) * freq
                    total_duration_months = total_duration_days / 30.0
                    if total_duration_months > state.max_installment_months and opt.number_of_payments > state.max_installment_months:
                        continue

                # Build installment dates
                first_dt = pd.to_datetime(opt.first_payment_date)
                freq_days = opt.payment_frequency_days if opt.payment_frequency_days else 30.0
                
                inst_sched = []
                payments_dict = {}
                for i in range(opt.number_of_payments):
                    inst_dt = first_dt + timedelta(days=int(i * freq_days))
                    inst_date_str = inst_dt.strftime('%Y-%m-%d')
                    inst_sched.append((inst_date_str, opt.payment_amount))
                    payments_dict[inst_date_str] = payments_dict.get(inst_date_str, 0.0) + opt.payment_amount

                last_payment_date = inst_sched[-1][0]
                finishes_by_deadline = (last_payment_date <= due_date)
                h_days = (pd.to_datetime(last_payment_date) - pd.to_datetime(req_date)).days

                # Simulate plan safety
                min_seen, is_safe, _ = self.forecaster.simulate_schedule(
                    state, req_date, proposed_payments=payments_dict, spending_changes=spending_changes, horizon_days=h_days
                )

                if is_safe and finishes_by_deadline:
                    status = 'affordable_with_plan'
                    plans.append(CandidatePlan(
                        method='installments',
                        payment_schedule=inst_sched,
                        spending_changes=list(spending_changes),
                        total_amount=opt.total_payable_amount,
                        first_payment_date=opt.first_payment_date,
                        number_of_payments=opt.number_of_payments,
                        payment_option_id=opt.payment_option_id,
                        is_safe=True,
                        affordability_status=status,
                        earliest_date_for_full_payment=earliest_date_for_full_payment
                    ))

        # 4. Wait Candidate
        if (not spending_changes and 
            'full_payment' in state.allowed_payment_methods and 
            earliest_date_for_full_payment is not None and 
            earliest_date_for_full_payment <= due_date and 
            earliest_date_for_full_payment > req_date):
            
            wait_sched = [(earliest_date_for_full_payment, req_amt)]
            payments_dict = {earliest_date_for_full_payment: req_amt}
            h_days = (pd.to_datetime(earliest_date_for_full_payment) - pd.to_datetime(req_date)).days
            min_seen, is_safe, _ = self.forecaster.simulate_schedule(
                state, req_date, proposed_payments=payments_dict, spending_changes=[], horizon_days=h_days
            )
            if is_safe:
                plans.append(CandidatePlan(
                    method='wait',
                    payment_schedule=wait_sched,
                    spending_changes=[],
                    total_amount=req_amt,
                    first_payment_date=earliest_date_for_full_payment,
                    number_of_payments=1,
                    payment_option_id=None,
                    is_safe=True,
                    affordability_status='affordable_later',
                    earliest_date_for_full_payment=earliest_date_for_full_payment
                ))

        return plans
