import itertools
from typing import List, Dict, Tuple, Optional
import pandas as pd

from models import EvaluationRequest, PaymentOption, CandidatePlan, RecommendationOutput
from financial_state import FinancialState
from forecast import ForecastEngine
from safe_amount import SafeAmountCalculator
from payment_planner import PaymentPlanner

class DecisionEngine:
    def __init__(self, forecast_engine: ForecastEngine,
                 safe_calc: SafeAmountCalculator,
                 planner: PaymentPlanner):
        self.forecaster = forecast_engine
        self.safe_calc = safe_calc
        self.planner = planner

    def generate_explanation(self, plan: CandidatePlan, request: EvaluationRequest,
                             state: FinancialState, amount_safe_to_pay: float) -> str:
        curr = state.home_currency
        min_bal_str = f"{curr} {state.minimum_balance_to_keep:,.2f}".replace('.00', '')
        req_amt_str = f"{curr} {request.requested_amount:,.2f}".replace('.00', '')

        if plan.method == 'full_payment':
            if not plan.spending_changes:
                return f"Pay {req_amt_str} today. This leaves at least {min_bal_str} available over the next 90 days."
            else:
                changes_text = []
                for ch in plan.spending_changes:
                    if ch.startswith('stop:'):
                        ev_id = ch.split(':')[1]
                        all_pool = state.recurring_expenses + state.flexible_events
                        desc = next((r['description'].lower() for r in all_pool if r['event_id'] == ev_id), "subscription")
                        changes_text.append(f"Stop the {desc}")
                    elif ch.startswith('reduce_to:'):
                        parts = ch.split(':')
                        ev_id = parts[1]
                        val = float(parts[2])
                        val_str = f"{curr} {val:,.2f}".replace('.00', '')
                        all_pool = state.recurring_expenses + state.flexible_events
                        desc = next((r['description'].lower() for r in all_pool if r['event_id'] == ev_id), "expense")
                        changes_text.append(f"reduce the {desc} to {val_str}")
                changes_str = " and ".join(changes_text)
                return f"{changes_str}, then pay {req_amt_str} today. This leaves at least {min_bal_str} available."

        elif plan.method == 'partial_payment':
            first_pay = plan.payment_schedule[0][1]
            second_pay = plan.payment_schedule[1][1]
            second_date = plan.payment_schedule[1][0]
            dt_obj = pd.to_datetime(second_date)
            date_formatted = dt_obj.strftime('%d %B %Y').lstrip('0')
            first_str = f"{curr} {first_pay:,.2f}".replace('.00', '')
            second_str = f"{curr} {second_pay:,.2f}".replace('.00', '')
            return f"Pay {first_str} today and the remaining {second_str} on {date_formatted}. This completes the full request and keeps the {min_bal_str} minimum protected."

        elif plan.method == 'installments':
            n = plan.number_of_payments
            inst_amt = plan.payment_schedule[0][1]
            inst_amt_str = f"{curr} {inst_amt:,.2f}".replace('.00', '')
            first_date = plan.first_payment_date
            dt_obj = pd.to_datetime(first_date)
            date_formatted = dt_obj.strftime('%d %B %Y').lstrip('0')
            return f"Use {n} installments of {inst_amt_str}, starting {date_formatted}. This leaves at least {min_bal_str} available."

        elif plan.method == 'wait':
            wait_date = plan.first_payment_date
            dt_obj = pd.to_datetime(wait_date)
            date_formatted = dt_obj.strftime('%d %B %Y').lstrip('0')
            return f"Pay {req_amt_str} in full on {date_formatted}. Paying earlier would take the balance below the {min_bal_str} minimum."

        else:  # not_recommended
            due_dt = pd.to_datetime(request.desired_completion_date)
            due_formatted = due_dt.strftime('%d %B %Y').lstrip('0')
            if amount_safe_to_pay > 0:
                safe_str = f"{curr} {amount_safe_to_pay:,.2f}".replace('.00', '')
                return f"Do not proceed with the {req_amt_str} request. Although {safe_str} is available today, the full amount cannot be completed safely within 90 days."
            return f"Do not make this payment by {due_formatted}. None of the available options keeps the {min_bal_str} minimum protected."

    def find_best_spending_changes(self, request: EvaluationRequest, state: FinancialState,
                                   options: List[PaymentOption],
                                   amount_safe_to_pay: float,
                                   earliest_date_for_full_payment: Optional[str]) -> List[CandidatePlan]:
        """Explores combinations of up to 3 spending adjustments."""
        candidate_changes = []

        candidate_pool = list(state.recurring_expenses) + list(state.flexible_events)
        seen_events = set()

        for rec in candidate_pool:
            ev_id = rec['event_id']
            if ev_id in seen_events:
                continue
            seen_events.add(ev_id)

            cat = rec['category']
            flex = rec['flexibility']

            # Stoppable option
            if cat in state.stoppable_categories and flex in ['stoppable', 'reducible_or_stoppable']:
                saving = rec['amount']
                candidate_changes.append((f"stop:{ev_id}", saving, ev_id))

            # Reducible option
            if cat in state.reducible_categories and flex in ['reducible', 'reducible_or_stoppable']:
                if rec['minimum_allowed_amount'] is not None:
                    saving = rec['amount'] - rec['minimum_allowed_amount']
                    if saving > 0:
                        candidate_changes.append((f"reduce_to:{ev_id}:{rec['minimum_allowed_amount']}", saving, ev_id))

        # Sort candidate changes by saving descending and take top 6 to prune search space
        candidate_changes.sort(key=lambda x: x[1], reverse=True)
        pruned_candidates = candidate_changes[:6]

        successful_plans = []

        # Try 1 change, then 2, then 3 changes
        for k in range(1, min(4, len(pruned_candidates) + 1)):
            for combo_items in itertools.combinations(pruned_candidates, k):
                event_ids = [item[2] for item in combo_items]
                # Ensure mutual exclusivity on event_id
                if len(event_ids) != len(set(event_ids)):
                    continue

                combo_strings = [item[0] for item in combo_items]
                plans = self.planner.generate_candidate_plans(
                    request, state, options, amount_safe_to_pay, earliest_date_for_full_payment,
                    spending_changes=combo_strings
                )
                safe_plans = [p for p in plans if p.is_safe]
                if safe_plans:
                    successful_plans.extend(safe_plans)
            
            # Prefer fewer changes per tie-breaker rule
            if successful_plans:
                break

        return successful_plans


    def rank_plans(self, plans: List[CandidatePlan]) -> List[CandidatePlan]:
        """
        Ranks plans according to the challenge tie-breaker rules:
        1. Complete by desired_completion_date (all candidate plans here already do)
        2. Require no spending changes (len(spending_changes) asc)
        3. Minimize total amount paid (total_amount asc)
        4. Start payment earlier (first_payment_date asc)
        5. Use fewer payments (number_of_payments asc)
        6. Lowest payment_option_id (payment_option_id asc)
        """
        def sort_key(p: CandidatePlan):
            num_changes = len(p.spending_changes)
            tot_amt = round(p.total_amount, 2)
            first_date = p.first_payment_date if p.first_payment_date else "9999-99-99"
            num_payments = p.number_of_payments
            opt_id = p.payment_option_id if p.payment_option_id else "zzzzzz"
            return (num_changes, tot_amt, first_date, num_payments, opt_id)

        return sorted(plans, key=sort_key)

    def decide(self, request: EvaluationRequest, state: FinancialState,
               options: List[PaymentOption]) -> RecommendationOutput:
        # Step 1: Compute baseline safe amount & earliest date
        amount_safe = self.safe_calc.compute_safe_amount(
            state, request.request_date, request.requested_amount, request.desired_completion_date
        )
        earliest_date = self.safe_calc.compute_earliest_date_for_full_payment(
            state, request.request_date, request.requested_amount, amount_safe, request.desired_completion_date
        )

        # Step 2: Generate candidate plans without spending changes
        plans_without_changes = self.planner.generate_candidate_plans(
            request, state, options, amount_safe, earliest_date, spending_changes=[]
        )
        safe_plans = [p for p in plans_without_changes if p.is_safe]

        winning_plan: Optional[CandidatePlan] = None

        if safe_plans:
            ranked = self.rank_plans(safe_plans)
            winning_plan = ranked[0]
        else:
            # Step 3: Try spending changes
            plans_with_changes = self.find_best_spending_changes(
                request, state, options, amount_safe, earliest_date
            )
            if plans_with_changes:
                ranked = self.rank_plans(plans_with_changes)
                winning_plan = ranked[0]

        # Step 4: Fallback to not_recommended if still no safe plan
        if winning_plan is None:
            winning_plan = CandidatePlan(
                method='not_recommended',
                payment_schedule=[],
                spending_changes=[],
                total_amount=0.0,
                first_payment_date=None,
                number_of_payments=0,
                payment_option_id=None,
                is_safe=False,
                affordability_status='not_affordable',
                earliest_date_for_full_payment=None
            )

        # Step 5: Format outputs matching exact challenge specifications
        plan_str = "none"
        if winning_plan.payment_schedule:
            # Format: YYYY-MM-DD:amt|YYYY-MM-DD:amt
            def fmt_amt(val):
                if float(val).is_integer():
                    return f"{int(val)}"
                return f"{float(val):.2f}"
            plan_str = "|".join(f"{dt}:{fmt_amt(amt)}" for dt, amt in winning_plan.payment_schedule)

        changes_str = "none"
        if winning_plan.spending_changes:
            changes_str = "|".join(winning_plan.spending_changes)

        earliest_str = winning_plan.earliest_date_for_full_payment if winning_plan.earliest_date_for_full_payment else ""

        explanation = self.generate_explanation(winning_plan, request, state, amount_safe)

        return RecommendationOutput(
            request_id=request.request_id,
            amount_safe_to_pay=amount_safe,
            affordability_status=winning_plan.affordability_status,
            recommended_payment_method=winning_plan.method,
            payment_plan=plan_str,
            earliest_date_for_full_payment=earliest_str,
            spending_changes_needed=changes_str,
            decision_explanation=explanation
        )
