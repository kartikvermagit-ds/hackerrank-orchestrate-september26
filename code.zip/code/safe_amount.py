from typing import Optional, Tuple, List
from datetime import datetime, timedelta
import pandas as pd
from financial_state import FinancialState
from forecast import ForecastEngine

class SafeAmountCalculator:
    def __init__(self, forecast_engine: ForecastEngine):
        self.forecaster = forecast_engine

    def compute_safe_amount(self, state: FinancialState, request_date: str, requested_amount: float,
                            desired_completion_date: Optional[str] = None) -> float:
        """
        Computes amount_safe_to_pay on request_date before optional spending changes.
        0 <= amount_safe_to_pay <= requested_amount.
        """
        h_days = 90
        if desired_completion_date and (state.salary_amount is None or state.salary_amount <= 0):
            req_days = (pd.to_datetime(desired_completion_date) - pd.to_datetime(request_date)).days
            if req_days > 0:
                h_days = min(90, req_days)

        min_seen, _, _ = self.forecaster.simulate_schedule(
            state, request_date, proposed_payments=None, spending_changes=None, horizon_days=h_days
        )
        headroom = min_seen - state.minimum_balance_to_keep
        if headroom <= 0:
            return 0.0
        return min(requested_amount, round(headroom, 2))

    def compute_earliest_date_for_full_payment(self, state: FinancialState, request_date: str,
                                               requested_amount: float,
                                               amount_safe_to_pay: float,
                                               desired_completion_date: Optional[str] = None) -> Optional[str]:
        """
        Finds the earliest date when a single full payment of requested_amount is safe.
        If safe today, returns request_date.
        Otherwise checks future confirmed salary paydays within 90 days.
        """
        if amount_safe_to_pay >= requested_amount:
            return request_date

        if state.salary_amount is None or state.salary_amount <= 0:
            return None

        req_dt = pd.to_datetime(request_date)
        sal_day = state.salary_day_of_month if state.salary_day_of_month else 15
        next_sal = state.next_salary_date

        paydays = []
        for day_offset in range(1, 91):
            cand_dt = req_dt + timedelta(days=day_offset)
            cand_date_str = cand_dt.strftime('%Y-%m-%d')
            if (next_sal and cand_date_str == next_sal) or (cand_dt.day == sal_day):
                paydays.append((cand_date_str, day_offset))

        for i, (cand_date_str, day_offset) in enumerate(paydays):
            payments = {cand_date_str: requested_amount}
            if i + 1 < len(paydays):
                h_days = paydays[i+1][1]
            else:
                h_days = min(90, day_offset + 15)

            min_seen, is_safe, _ = self.forecaster.simulate_schedule(
                state, request_date, proposed_payments=payments, horizon_days=h_days
            )
            if is_safe:
                return cand_date_str

        return None
