from typing import List, Dict, Tuple, Optional, Set
from datetime import datetime, timedelta
from collections import Counter
import pandas as pd
from models import FinancialEvent, Message
from currency import CurrencyConverter
from message_processor import MessageProcessor, SalaryUpdate

class EventNormalizer:
    def __init__(self, currency_converter: CurrencyConverter, message_processor: MessageProcessor):
        self.fx = currency_converter
        self.msg_proc = message_processor

    def normalize_events_for_user(self, events: List[FinancialEvent], home_currency: str) -> List[FinancialEvent]:
        """Convert all events to home currency, drop cancelled and unrealized."""
        valid_events = []
        for e in events:
            if e.status == 'cancelled':
                continue
            if e.direction == 'non_cash' or e.status == 'unrealized':
                continue
            
            # Convert currency to home_currency
            if e.currency != home_currency:
                rate_date = e.settlement_date if e.settlement_date else e.event_date
                converted_amt = self.fx.convert(e.amount, e.currency, home_currency, rate_date)
                e.amount = converted_amt
                e.currency = home_currency
                if e.minimum_allowed_amount is not None:
                    e.minimum_allowed_amount = self.fx.convert(e.minimum_allowed_amount, e.currency, home_currency, rate_date)

            valid_events.append(e)

        return valid_events

    FIXED_MONTHLY_CATEGORIES = {
        'rent', 'utilities', 'debt_repayment', 'insurance', 'education', 
        'housing', 'subscription', 'cloud_storage', 'streaming', 
        'music_subscription', 'delivery_membership', 'gym', 'entertainment',
        'healthcare', 'family_support'
    }

    def extract_recurring_monthly_expenses(self, events: List[FinancialEvent], request_date: str) -> List[Dict]:
        """Identify monthly fixed debits that recur on a specific day of month."""
        groups = {}
        for e in events:
            if e.direction == 'debit' and e.status == 'settled' and e.event_date < request_date:
                if e.category in self.FIXED_MONTHLY_CATEGORIES:
                    key = (e.category, e.description, e.flexibility)
                    groups.setdefault(key, []).append(e)

        recurring = []
        for (cat, desc, flex), ev_list in groups.items():
            if len(ev_list) >= 2:
                sorted_evs = sorted(ev_list, key=lambda x: x.event_date)
                dates = [pd.to_datetime(x.event_date) for x in sorted_evs]
                intervals = [(dates[i] - dates[i-1]).days for i in range(1, len(dates))]
                avg_interval = sum(intervals) / len(intervals) if intervals else 30
                
                # Monthly cadence (20 to 35 days)
                if 20 <= avg_interval <= 35 or len(ev_list) >= 2:
                    last_ev = sorted_evs[-1]
                    day_of_month = pd.to_datetime(last_ev.event_date).day
                    min_allowed = last_ev.minimum_allowed_amount
                    
                    recurring.append({
                        'category': cat,
                        'description': desc,
                        'flexibility': flex,
                        'amount': last_ev.amount,
                        'day_of_month': day_of_month,
                        'last_date': last_ev.event_date,
                        'event_id': last_ev.event_id,
                        'minimum_allowed_amount': min_allowed
                    })

        return recurring

    def calculate_variable_daily_burn(self, events: List[FinancialEvent], request_date: str,
                                      recurring_categories: Set[str]) -> float:
        """Calculates daily burn rate for essential variable living categories (groceries, transport, dining)."""
        req_dt = pd.to_datetime(request_date)
        start_dt = req_dt - pd.Timedelta(days=60)
        
        living_cats = {'groceries', 'transport', 'dining'}
        var_debits = [
            e.amount for e in events 
            if e.status == 'settled' and e.direction == 'debit' and e.category in living_cats 
            and start_dt <= pd.to_datetime(e.event_date) < req_dt
        ]
        if not var_debits:
            return 0.0
        return sum(var_debits) / 60.0

    def get_salary_info(self, user_id: str, events: List[FinancialEvent], request_date: str) -> Tuple[Optional[float], Optional[int], Optional[str]]:
        """
        Returns (salary_amount, salary_day_of_month, next_confirmed_salary_date).
        Distinguishes regular confirmed salary from variable gig platform payouts.
        """
        salary_update = self.msg_proc.get_salary_update_for_user(user_id, request_date)
        
        # If contract ended, no future salary
        if salary_update and salary_update.contract_ended:
            return None, None, None

        # Check for scheduled 'Next confirmed salary' in events
        scheduled_salaries = [e for e in events if e.status == 'scheduled' and 'salary' in e.description.lower()]
        next_date = None
        next_amt = None
        if scheduled_salaries:
            next_date = scheduled_salaries[0].settlement_date
            next_amt = scheduled_salaries[0].amount

        # Filter regular settled salaries (ignore platform/gig payouts like Driver/Delivery platform payout)
        regular_keywords = ['payroll', 'salary', 'base salary', 'first-job', 'promotion arrears']
        gig_keywords = ['platform', 'driver', 'marketplace', 'freelance', 'contract payment', 'gig', 'app earnings', 'weekly app', 'earnings', 'seasonal', 'temporary']

        settled_regular_salaries = []
        for e in events:
            if e.status == 'settled' and (e.category == 'salary' or e.event_type == 'income'):
                desc_lower = e.description.lower()
                is_gig = any(k in desc_lower for k in gig_keywords)
                is_regular = any(k in desc_lower for k in regular_keywords) or (e.category == 'salary' and not is_gig)
                if is_regular and not is_gig:
                    settled_regular_salaries.append(e)

        if not settled_regular_salaries and next_amt is None and (not salary_update or salary_update.new_salary is None):
            # No regular confirmed salary (e.g. gig worker)
            return None, None, None

        base_amt = next_amt
        salary_day = 15

        if settled_regular_salaries:
            sorted_salaries = sorted(settled_regular_salaries, key=lambda x: x.event_date)
            # If final payroll, contract ended
            if 'final' in sorted_salaries[-1].description.lower():
                return None, None, None
            
            if base_amt is None:
                base_amt = sorted_salaries[-1].amount
            
            # Find most common day of month for salary
            sal_days = [pd.to_datetime(s.event_date).day for s in settled_regular_salaries]
            if sal_days:
                salary_day = Counter(sal_days).most_common(1)[0][0]

        # Apply message updates
        if salary_update:
            if salary_update.new_salary is not None:
                base_amt = salary_update.new_salary
            if salary_update.revised_pay_date:
                next_date = salary_update.revised_pay_date
                salary_day = pd.to_datetime(next_date).day

        return base_amt, salary_day, next_date
