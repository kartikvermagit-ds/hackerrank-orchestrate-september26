from typing import List, Dict, Tuple, Optional, Set
from datetime import datetime, timedelta
import pandas as pd
from financial_state import FinancialState

class ForecastEngine:
    """Deterministic 90-day daily balance simulator."""

    def __init__(self):
        pass

    def simulate_schedule(self, state: FinancialState, request_date: str,
                          proposed_payments: Optional[Dict[str, float]] = None,
                          spending_changes: Optional[List[str]] = None,
                          horizon_days: int = 90) -> Tuple[float, bool, List[Tuple[str, float]]]:
        """
        Simulates daily balance over horizon_days starting from request_date.
        Returns (min_balance_seen, is_safe, daily_balances).
        """
        if proposed_payments is None:
            proposed_payments = {}
        if spending_changes is None:
            spending_changes = []

        stopped_event_ids: Set[str] = set()
        reduced_amounts: Dict[str, float] = {}

        for change in spending_changes:
            if change.startswith('stop:'):
                ev_id = change.split(':', 1)[1].strip()
                stopped_event_ids.add(ev_id)
            elif change.startswith('reduce_to:'):
                parts = change.split(':')
                if len(parts) == 3:
                    ev_id = parts[1].strip()
                    val = float(parts[2].strip())
                    reduced_amounts[ev_id] = val

        # Variable burn savings from spending changes on non-monthly flexible events
        burn_saving_per_day = 0.0
        rec_event_ids = {r['event_id'] for r in state.recurring_expenses}
        flex_by_id = {f['event_id']: f for f in state.flexible_events}

        for ev_id in stopped_event_ids:
            if ev_id not in rec_event_ids and ev_id in flex_by_id:
                burn_saving_per_day += flex_by_id[ev_id]['amount'] / 30.0

        for ev_id, red_amt in reduced_amounts.items():
            if ev_id not in rec_event_ids and ev_id in flex_by_id:
                saving = flex_by_id[ev_id]['amount'] - red_amt
                if saving > 0:
                    burn_saving_per_day += saving / 30.0

        effective_daily_burn = max(0.0, state.daily_variable_burn - burn_saving_per_day)

        req_dt = pd.to_datetime(request_date)
        current_bal = state.liquid_starting_balance
        min_bal_seen = current_bal
        daily_records: List[Tuple[str, float]] = []

        sal_amt = state.salary_amount
        sal_day = state.salary_day_of_month if state.salary_day_of_month else 15
        next_sal_dt = state.next_salary_date

        seen_first_salary = False

        for offset in range(horizon_days + 1):
            dt = req_dt + timedelta(days=offset)
            dt_str = dt.strftime('%Y-%m-%d')

            # 1. Salary Inflow (offset > 0, because offset 0 is current liquid starting balance)
            if offset > 0 and sal_amt is not None:
                is_sal = False
                if next_sal_dt and dt_str == next_sal_dt:
                    is_sal = True
                elif dt.day == sal_day:
                    is_sal = True
                
                if is_sal:
                    current_bal += sal_amt
                    seen_first_salary = True

            # 2. Outflow: Scheduled Debits
            if dt_str in state.scheduled_debits:
                current_bal -= state.scheduled_debits[dt_str]

            # 3. Outflow: Recurring Monthly Expenses
            for rec in state.recurring_expenses:
                ev_id = rec['event_id']
                if ev_id in stopped_event_ids:
                    continue

                amt = rec['amount']
                if ev_id in reduced_amounts:
                    amt = reduced_amounts[ev_id]

                # Check day of month
                if dt.day == rec['day_of_month']:
                    last_dt = pd.to_datetime(rec['last_date'])
                    if offset == 0 and rec['last_date'] == dt_str:
                        # Already settled in starting balance
                        pass
                    elif dt > last_dt:
                        current_bal -= amt

            # 4. Outflow: Variable Living Expenses Burn
            if offset > 0:
                current_bal -= effective_daily_burn

            # 5. Proposed Payments
            if dt_str in proposed_payments:
                current_bal -= proposed_payments[dt_str]

            min_bal_seen = min(min_bal_seen, current_bal)
            daily_records.append((dt_str, current_bal))

        is_safe = (min_bal_seen >= state.minimum_balance_to_keep - 0.05)
        return min_bal_seen, is_safe, daily_records
